<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Crash3" tilewidth="32" tileheight="32" tilecount="70" columns="10">
 <image source="Crash3.PNG" width="320" height="224"/>
</tileset>
