<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Crash4" tilewidth="32" tileheight="32" tilecount="20" columns="10">
 <image source="Crash4.png" width="320" height="64"/>
</tileset>
