<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="tree" tilewidth="32" tileheight="32" tilecount="126" columns="9">
 <image source="tree.png" width="288" height="450"/>
</tileset>
