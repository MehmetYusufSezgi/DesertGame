<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Desert" tilewidth="32" tileheight="32" tilecount="35" columns="7">
 <image source="Desert.png" width="224" height="166"/>
</tileset>
