<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="skull-emoji" tilewidth="32" tileheight="32" tilecount="160" columns="10">
 <image source="skull-emoji.gif" width="320" height="512"/>
</tileset>
