<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="tree3" tilewidth="32" tileheight="32" tilecount="50" columns="5">
 <image source="tree3.png" width="160" height="320"/>
</tileset>
