<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="DungeonCrawl_ProjectUtumnoTileset" tilewidth="32" tileheight="32" tilecount="3072" columns="64">
 <image source="DungeonCrawl_ProjectUtumnoTileset.png" width="2048" height="1536"/>
 <tile id="781">
  <animation>
   <frame tileid="781" duration="100"/>
   <frame tileid="782" duration="100"/>
   <frame tileid="783" duration="100"/>
   <frame tileid="784" duration="100"/>
   <frame tileid="785" duration="100"/>
   <frame tileid="786" duration="100"/>
   <frame tileid="787" duration="100"/>
   <frame tileid="788" duration="100"/>
  </animation>
 </tile>
 <tile id="1209">
  <animation>
   <frame tileid="1209" duration="100"/>
   <frame tileid="1210" duration="100"/>
   <frame tileid="1211" duration="100"/>
   <frame tileid="1212" duration="100"/>
  </animation>
 </tile>
 <tile id="1210">
  <animation>
   <frame tileid="1209" duration="100"/>
   <frame tileid="1210" duration="100"/>
   <frame tileid="1211" duration="100"/>
   <frame tileid="1212" duration="100"/>
  </animation>
 </tile>
</tileset>
