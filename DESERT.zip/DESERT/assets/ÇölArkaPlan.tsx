<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Ekran Alıntısı" tilewidth="32" tileheight="32" tilecount="468" columns="26">
 <image source="Ekran Alıntısı.PNG" width="845" height="579"/>
</tileset>
